import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  model:any;
  constructor() { }

  ngOnInit(): void {
    this.model= 
    [
      
       {Id: 1, Name: 'Product 1',  Image: 'https://lh3.googleusercontent.com/proxy/haFGDg0kI3N8IUYlgg1PtDE-CwYubAW5Jhe46iwsupZ4VNC7aUupiJ4mmsOpNYmSNWQ5f4-1E8N_woQokVSTgDFEySnxkdQ',Price:5},
       {Id: 2, Name: 'Product 2',  Image: 'https://ii1.pepperfry.com/media/catalog/product/m/a/800x400/max-three-seater-sofa-in-tan-leatherette-by-furniture-mind-max-three-seater-sofa-in-tan-leatherette--kyb8ol.jpg',Price:15}, 
       {Id: 3, Name: 'Product 3',  Image: 'https://www.lg.com/in/images/TV/features/signature-brand-productslink-d-type2.jpg ',Price:105},
       {Id: 4, Name: 'Product 4',  Image: 'https://www.dermstore.com/blog/wp-content/uploads/2018/01/080819-Body-Prods.jpg',Price:25},
       {Id: 5, Name: 'Product 5',  Image: 'https://cdn2.stylecraze.com/wp-content/uploads/2013/03/Best-Pond%E2%80%99s-Products-Available-In-India-%E2%80%93-Our-Top-10-1.jpg.webp',Price:8}, 
       {Id: 6, Name: 'Product 6',  Image: 'https://methodhome.com/wp-content/uploads/laundry_p-v2-500x500.png ',Price:6},
    ]
  
  
  }




}
